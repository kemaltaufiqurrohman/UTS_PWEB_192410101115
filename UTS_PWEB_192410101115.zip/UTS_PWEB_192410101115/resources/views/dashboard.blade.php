{{-- Dashboard --}}
{{-- halaman utama setelah login --}}

@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
{{-- Alert sukses login --}}
<x-alert type="success" message="Login berhasil! Selamat datang 😊" />

<h3 class="mb-4" style="font-weight: 600; color: #2c3e50;">
    Halo, {{ $username }} 👋
</h3>
<p class="text-muted" style="font-size: 14px;">
    Silakan pilih menu.
</p>

<div class="row mt-4">

    {{-- Card Pengelolaan Data --}}
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0" style="border-radius: 16px;">
            <div class="card-body">
                <h5 class="fw-bold mb-2">
                    <i class="bi bi-table me-2"></i> Pengelolaan Data Mahasiswa
                </h5>
                <p class="text-muted" style="font-size: 13px;">
                    Lihat daftar mahasiswa yang tersedia pada sistem.
                </p>
                <a href="{{ route('pengelolaan', request()->only('username')) }}" 
                   class="btn btn-primary btn-sm" style="border-radius: 8px;">
                    Lihat Data
                </a>
            </div>
        </div>
    </div>

    {{-- Card Profil --}}
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0" style="border-radius: 16px;">
            <div class="card-body">
                <h5 class="fw-bold mb-2">
                    <i class="bi bi-person-circle me-2"></i> Profil Mahasiswa
                </h5>
                <p class="text-muted" style="font-size: 13px;">
                    Lihat data diri.
                </p>
                <a href="{{ route('profile', request()->only('username')) }}" 
                   class="btn btn-outline-primary btn-sm" style="border-radius: 8px;">
                    Lihat Profil
                </a>
            </div>
        </div>
    </div>

</div>
@endsection

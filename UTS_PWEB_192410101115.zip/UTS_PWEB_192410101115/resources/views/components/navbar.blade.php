{{-- Navbar --}}
{{-- bagian atas yang ada di semua halaman --}}

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="{{ route('dashboard', request()->only('username')) }}">UTS PWEB</a>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        {{-- menu navigasi utama --}}
        <li class="nav-item"><a class="nav-link" href="{{ route('dashboard', request()->only('username')) }}">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="{{ route('pengelolaan', request()->only('username')) }}">Pengelolaan</a></li>
        <li class="nav-item"><a class="nav-link" href="{{ route('profile', request()->only('username')) }}">Profile</a></li>
      </ul>
      {{-- bagian kanan navbar --}}
      <div class="d-flex">
        @if(request('username'))
          <span class="navbar-text me-3">Halo, {{ request('username') }}</span>
        @endif
        <a href="{{ route('login') }}" class="btn btn-outline-danger btn-sm">Logout</a>
      </div>
    </div>
  </div>
</nav>

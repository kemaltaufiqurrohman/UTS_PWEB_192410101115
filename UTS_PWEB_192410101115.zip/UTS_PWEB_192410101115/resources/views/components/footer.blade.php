{{-- Footer --}}
{{-- bagian bawah tiap halaman --}}

<footer class="footer">
  <div class="container text-center">
    <small>
      UTS PWEB 2025 — Pengelolaan Data Mahasiswa<br>
      Dibuat oleh: Kemal Taufiqurrohman (192410101115)<br>
      Sistem Informasi - Fakultas Ilmu Komputer - Universitas Jember
    </small>
  </div>
</footer>

{{-- Untuk menampilkan pesan notifikasi seperti error atau sukses --}}

@props(['type' => 'info', 'message' => ''])

@php
    // warna alert berdasarkan tipe
    $color = match($type) {
        'success' => 'alert-success border-success text-success',
        'danger' => 'alert-danger border-danger text-danger',
        'warning' => 'alert-warning border-warning text-warning',
        default => 'alert-info border-info text-info',
    };
@endphp

<div class="alert {{ $color }} d-flex align-items-center p-2" role="alert" style="border-radius: 10px;">
    <i class="bi bi-info-circle me-2"></i>
    <div style="font-size: 14px;">
        {{ $message }}
    </div>
</div>

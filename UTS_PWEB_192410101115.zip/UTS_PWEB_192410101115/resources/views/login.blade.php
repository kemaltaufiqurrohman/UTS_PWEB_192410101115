{{-- Halaman Login --}}
{{-- User masukin username untuk bisa ke halaman dashboard --}}

@extends('layouts.app')

@section('title', 'Login')

@section('content')
<div class="row justify-content-center" style="margin-top: 80px;">
    <div class="col-md-5">
        <div class="card shadow-lg border-0" style="border-radius: 18px;">
            <div class="card-body p-4">

                <h3 class="text-center mb-3" style="font-weight: 600; color: #2c3e50;">
                    Welcome!!!
                </h3>
                <p class="text-center mb-4 text-muted" style="font-size: 14px;">
                    Silakan login
                </p>

                {{-- Notif jika username tidak diisi --}}
                @if(session('error'))
                    <x-alert type="danger" :message="session('error')" />
                @endif

                {{-- Form untuk Login --}}
                <form method="POST" action="{{ route('login.post') }}">
                    @csrf

                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white">
                                <i class="bi bi-person"></i>
                            </span>
                            <input type="text" name="username" class="form-control" placeholder="Masukkan username Anda">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white">
                                <i class="bi bi-lock"></i>
                            </span>
                            <input type="password" name="password" class="form-control" placeholder="Masukkan password">
                        </div>
                    </div>

                    <button class="btn w-100 text-white" 
                        style="background: #3498db; border-radius: 10px; font-weight: 600;">
                        Masuk
                    </button>

                </form>

            </div>
        </div>
    </div>
</div>
@endsection

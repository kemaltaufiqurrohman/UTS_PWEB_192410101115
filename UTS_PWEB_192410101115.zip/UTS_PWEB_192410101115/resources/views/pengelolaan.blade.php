{{-- Pengelolaan Data --}}
{{-- Daftar mahasiswa dari array dummy --}}

@extends('layouts.app')

@section('title', 'Pengelolaan Data Mahasiswa')

@section('content')
<h3 class="mb-3" style="font-weight: 600; color: #2c3e50;">
    <i class="bi bi-table me-2"></i> Data Mahasiswa
</h3>

<p class="text-muted" style="font-size: 14px;">
    Berikut adalah daftar mahasiswa yang tersimpan pada sistem.
</p>

{{-- Tabel Data --}}
<div class="table-responsive">
    <table class="table table-bordered table-hover" style="border-radius: 12px; overflow: hidden;">
        <thead class="table-light">
            <tr>
                <th class="text-center">No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Prodi</th>
                <th>Angkatan</th>
            </tr>
        </thead>
        <tbody>
            @foreach($mahasiswa as $i => $m)
            <tr>
                <td class="text-center">{{ $i + 1 }}</td>
                <td>{{ $m['nim'] }}</td>
                <td>{{ $m['nama'] }}</td>
                <td>{{ $m['prodi'] }}</td>
                <td>{{ $m['angkatan'] }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection

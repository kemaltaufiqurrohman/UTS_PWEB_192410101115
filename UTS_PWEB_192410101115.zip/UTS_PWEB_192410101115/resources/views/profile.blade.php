{{-- Profil Mahasiswa --}}
{{-- Menampilkan data diri mahasiswa --}}

@extends('layouts.app')

@section('title', 'Profile')

@section('content')
<h3>Profil Mahasiswa</h3>
<div class="card w-50">
  <div class="card-body">
    <p><strong>Nama:</strong> {{ $profile['nama'] }}</p>
    <p><strong>NIM:</strong> {{ $profile['nim'] }}</p>
    <p><strong>Prodi:</strong> {{ $profile['prodi'] }}</p>
    <p><strong>Angkatan:</strong> {{ $profile['angkatan'] }}</p>
    <p><strong>Email:</strong> {{ $profile['email'] }}</p>
  </div>
</div>
@endsection

<?php
// Controller utama yang mengatur halaman login, dashboard, profile, dan pengelolaan data

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * UTS PWEB 25/26
 * Nama  : Kemal Taufiiqurrohman
 * NIM   : 192410101115
 * Prodi : Sistem Informasi - Universitas Jember
 */

class PageController extends Controller
{
    // tampilan form login
    public function login()
    {
        return view('login');
    }

    // proses data dari form login
    public function doLogin(Request $request)
    {
        $username = $request->input('username', 'Guest');

        // kalau kosong kembali ke login
        if (trim($username) === '') {
            return redirect()->route('login')->with('error', 'Username tidak boleh kosong!');
        }

        // kalau terisi diarahkan ke dashboard dengan nama user
        return redirect()->route('dashboard', ['username' => $username]);
    }

    // tampilan dashboard
    public function dashboard(Request $request)
    {
        $username = $request->query('username', 'Guest');
        return view('dashboard', compact('username'));
    }

    // tampilan data profil user yang login
    public function profile(Request $request)
    {
        $username = $request->query('username', 'Guest');
        // isi data dummy profil mahasiswa
        $profile = [
            'nama' => $username,
            'nim' => '192410101115',
            'prodi' => 'Sistem Informasi',
            'angkatan' => '2019',
            'email' => strtolower(str_replace(' ', '.', $username)) . '@mail.univ.ac.id',
        ];
        return view('profile', compact('username', 'profile'));
    }

    // tampilkan data mahasiswa (dummy array)
    public function pengelolaan(Request $request)
    {
        $username = $request->query('username', 'Guest');
        $mahasiswa = [
            ['nim' => '242410101001', 'nama' => 'Budi Santoso', 'prodi' => 'Sistem Informasi', 'angkatan' => '2024'],
            ['nim' => '242410102002', 'nama' => 'Siti Aminah', 'prodi' => 'Teknologi Informasi', 'angkatan' => '2024'],
            ['nim' => '242410103003', 'nama' => 'Agus Wijaya', 'prodi' => 'Informatika', 'angkatan' => '2024'],
        ];
        return view('pengelolaan', compact('username', 'mahasiswa'));
    }
}

<?php
// routes/web.php
// Rute utama untuk aplikasi UTS PWEB - Pengelolaan Data Mahasiswa
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;

// Halaman utama langsung diarahkan ke halaman login
Route::get('/', function () {
    return redirect()->route('login');
});

// halaman login
Route::get('/login', [PageController::class, 'login'])->name('login');

// proses login (post)
Route::post('/login', [PageController::class, 'doLogin'])->name('login.post');

// dashboard, profile, dan pengelolaan data
Route::get('/dashboard', [PageController::class, 'dashboard'])->name('dashboard');
Route::get('/profile', [PageController::class, 'profile'])->name('profile');
Route::get('/pengelolaan', [PageController::class, 'pengelolaan'])->name('pengelolaan');

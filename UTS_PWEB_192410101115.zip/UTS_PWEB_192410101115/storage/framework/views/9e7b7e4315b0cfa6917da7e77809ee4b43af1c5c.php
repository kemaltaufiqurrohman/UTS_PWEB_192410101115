




<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success','message' => 'Login berhasil! Selamat datang 😊']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','message' => 'Login berhasil! Selamat datang 😊']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<h3 class="mb-4" style="font-weight: 600; color: #2c3e50;">
    Halo, <?php echo e($username); ?> 👋
</h3>
<p class="text-muted" style="font-size: 14px;">
    Silakan pilih menu.
</p>

<div class="row mt-4">

    
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0" style="border-radius: 16px;">
            <div class="card-body">
                <h5 class="fw-bold mb-2">
                    <i class="bi bi-table me-2"></i> Pengelolaan Data Mahasiswa
                </h5>
                <p class="text-muted" style="font-size: 13px;">
                    Lihat daftar mahasiswa yang tersedia pada sistem.
                </p>
                <a href="<?php echo e(route('pengelolaan', request()->only('username'))); ?>" 
                   class="btn btn-primary btn-sm" style="border-radius: 8px;">
                    Lihat Data
                </a>
            </div>
        </div>
    </div>

    
    <div class="col-md-6 mb-3">
        <div class="card shadow-sm border-0" style="border-radius: 16px;">
            <div class="card-body">
                <h5 class="fw-bold mb-2">
                    <i class="bi bi-person-circle me-2"></i> Profil Mahasiswa
                </h5>
                <p class="text-muted" style="font-size: 13px;">
                    Lihat data diri.
                </p>
                <a href="<?php echo e(route('profile', request()->only('username'))); ?>" 
                   class="btn btn-outline-primary btn-sm" style="border-radius: 8px;">
                    Lihat Profil
                </a>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TOSHIBA\UTS_PWEB_192410101115\resources\views/dashboard.blade.php ENDPATH**/ ?>
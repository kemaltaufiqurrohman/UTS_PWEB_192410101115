




<?php $__env->startSection('title', 'Pengelolaan Data Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="mb-3" style="font-weight: 600; color: #2c3e50;">
    <i class="bi bi-table me-2"></i> Data Mahasiswa
</h3>

<p class="text-muted" style="font-size: 14px;">
    Berikut adalah daftar mahasiswa yang tersimpan pada sistem.
</p>


<div class="table-responsive">
    <table class="table table-bordered table-hover" style="border-radius: 12px; overflow: hidden;">
        <thead class="table-light">
            <tr>
                <th class="text-center">No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Prodi</th>
                <th>Angkatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($i + 1); ?></td>
                <td><?php echo e($m['nim']); ?></td>
                <td><?php echo e($m['nama']); ?></td>
                <td><?php echo e($m['prodi']); ?></td>
                <td><?php echo e($m['angkatan']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TOSHIBA\UTS_PWEB_192410101115\resources\views/pengelolaan.blade.php ENDPATH**/ ?>
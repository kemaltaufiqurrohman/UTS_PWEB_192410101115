


<footer class="footer">
  <div class="container text-center">
    <small>
      UTS PWEB 2025 — Pengelolaan Data Mahasiswa<br>
      Dibuat oleh: Kemal Taufiqurrohman (192410101115)<br>
      Sistem Informasi - Fakultas Ilmu Komputer - Universitas Jember
    </small>
  </div>
</footer>
<?php /**PATH C:\Users\TOSHIBA\UTS_PWEB_192410101115\resources\views/components/footer.blade.php ENDPATH**/ ?>
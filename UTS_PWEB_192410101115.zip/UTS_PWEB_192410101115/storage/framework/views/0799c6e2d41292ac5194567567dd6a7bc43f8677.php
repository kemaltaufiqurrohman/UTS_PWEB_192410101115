




<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<h3>Profil Mahasiswa</h3>
<div class="card w-50">
  <div class="card-body">
    <p><strong>Nama:</strong> <?php echo e($profile['nama']); ?></p>
    <p><strong>NIM:</strong> <?php echo e($profile['nim']); ?></p>
    <p><strong>Prodi:</strong> <?php echo e($profile['prodi']); ?></p>
    <p><strong>Angkatan:</strong> <?php echo e($profile['angkatan']); ?></p>
    <p><strong>Email:</strong> <?php echo e($profile['email']); ?></p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TOSHIBA\UTS_PWEB_192410101115\resources\views/profile.blade.php ENDPATH**/ ?>
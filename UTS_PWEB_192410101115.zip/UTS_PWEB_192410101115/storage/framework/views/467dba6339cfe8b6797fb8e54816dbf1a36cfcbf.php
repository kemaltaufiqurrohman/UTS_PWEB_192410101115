


<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(route('dashboard', request()->only('username'))); ?>">UTS PWEB</a>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard', request()->only('username'))); ?>">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pengelolaan', request()->only('username'))); ?>">Pengelolaan</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('profile', request()->only('username'))); ?>">Profile</a></li>
      </ul>
      
      <div class="d-flex">
        <?php if(request('username')): ?>
          <span class="navbar-text me-3">Halo, <?php echo e(request('username')); ?></span>
        <?php endif; ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-danger btn-sm">Logout</a>
      </div>
    </div>
  </div>
</nav>
<?php /**PATH C:\Users\TOSHIBA\UTS_PWEB_192410101115\resources\views/components/navbar.blade.php ENDPATH**/ ?>
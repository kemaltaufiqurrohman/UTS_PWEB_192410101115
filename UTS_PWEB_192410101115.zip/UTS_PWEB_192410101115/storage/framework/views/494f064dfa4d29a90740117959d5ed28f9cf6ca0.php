

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => 'info', 'message' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => 'info', 'message' => '']); ?>
<?php foreach (array_filter((['type' => 'info', 'message' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    // warna alert berdasarkan tipe
    $color = match($type) {
        'success' => 'alert-success border-success text-success',
        'danger' => 'alert-danger border-danger text-danger',
        'warning' => 'alert-warning border-warning text-warning',
        default => 'alert-info border-info text-info',
    };
?>

<div class="alert <?php echo e($color); ?> d-flex align-items-center p-2" role="alert" style="border-radius: 10px;">
    <i class="bi bi-info-circle me-2"></i>
    <div style="font-size: 14px;">
        <?php echo e($message); ?>

    </div>
</div>
<?php /**PATH C:\Users\TOSHIBA\UTS_PWEB_192410101115\resources\views/components/alert.blade.php ENDPATH**/ ?>